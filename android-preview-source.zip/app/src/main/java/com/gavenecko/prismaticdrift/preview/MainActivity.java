package com.gavenecko.prismaticdrift.preview;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.webkit.*;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final String HOST="appassets.androidplatform.net";
    private static final String HOME="https://"+HOST+"/assets/index.html";
    private WebView web;
    private FrameLayout root;
    private ValueCallback<Uri[]> fileCallback;
    private String exportData;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(14,20,37));
        root.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        setContentView(root);
        web=new WebView(this);web.setBackgroundColor(Color.BLACK);
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        web.addJavascriptInterface(new NativeBridge(),"PrismaticAndroid");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                Uri uri=request.getUrl();
                return !("https".equals(uri.getScheme())&&HOST.equals(uri.getHost()));
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                Uri uri=request.getUrl();
                if(!"https".equals(uri.getScheme())||!HOST.equals(uri.getHost()))return denied();
                String path=uri.getPath();
                if(path==null||!path.startsWith("/assets/")||path.contains(".."))return denied();
                String asset=path.substring(8);
                if(!asset.equals("index.html"))return denied();
                try{return new WebResourceResponse("text/html","UTF-8",200,"OK",
                    Collections.singletonMap("Content-Security-Policy","default-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'none'; object-src 'none'"),getAssets().open(asset));}
                catch(IOException ex){return denied();}
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);
                fileCallback=callback;
                try{startActivityForResult(params.createIntent(),100);}
                catch(ActivityNotFoundException ex){fileCallback=null;callback.onReceiveValue(null);toast("No file picker is available.");}
                return true;
            }
            @Override public void onShowCustomView(View view,CustomViewCallback callback){
                if(fullscreenView!=null){callback.onCustomViewHidden();return;}
                fullscreenView=view;fullscreenCallback=callback;
                root.addView(view,new FrameLayout.LayoutParams(-1,-1));
                web.setVisibility(View.GONE);
            }
            @Override public void onHideCustomView(){leaveFullscreen();}
        });
        web.loadUrl(HOME);
    }
    private static WebResourceResponse denied(){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void leaveFullscreen(){
        if(fullscreenView==null)return;
        root.removeView(fullscreenView);fullscreenView=null;web.setVisibility(View.VISIBLE);
        if(fullscreenCallback!=null)fullscreenCallback.onCustomViewHidden();fullscreenCallback=null;
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==100&&fileCallback!=null){
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;
        }else if(request==101){
            String text=exportData;exportData=null;
            if(result==RESULT_OK&&data!=null&&data.getData()!=null&&text!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new IOException("No output stream");out.write(text.getBytes(StandardCharsets.UTF_8));toast("Settings exported.");
                }catch(IOException ex){toast("Could not save this file.");}
            }
        }
    }
    @Override protected void onPause(){
        if(web!=null){web.evaluateJavascript("window.pdNativePaused=true;document.querySelectorAll('audio').forEach(a=>a.pause())",null);web.onPause();}
        super.onPause();
    }
    @Override protected void onResume(){super.onResume();if(web!=null){web.onResume();web.evaluateJavascript("window.pdNativePaused=false",null);}}
    @Override public void onBackPressed(){if(fullscreenView!=null)leaveFullscreen();else super.onBackPressed();}
    @Override protected void onDestroy(){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        if(web!=null){web.removeJavascriptInterface("PrismaticAndroid");root.removeView(web);web.destroy();}
        super.onDestroy();
    }
    private final class NativeBridge {
        @JavascriptInterface public void saveWallpaperScene(String json){
            if(json==null||json.length()>1000000)return;
            try{
                JSONObject value=new JSONObject(json);
                if(value.optJSONObject("controls")==null)return;
                getSharedPreferences("wallpaper",MODE_PRIVATE).edit().putString("scene",value.toString()).apply();
                runOnUiThread(()->toast("Main shapes and colours saved for wallpaper."));
            }catch(Exception ignored){}
        }
        @JavascriptInterface public void openWallpaperSettings(){runOnUiThread(()->startActivity(new Intent(MainActivity.this,WallpaperSettingsActivity.class)));}
        @JavascriptInterface public void exportSettings(String json){
            if(json==null||json.length()>2000000)return;
            try{new JSONObject(json);}catch(Exception ex){return;}
            runOnUiThread(()->{
                exportData=json;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE,"Prismatic-Drift-settings.json");
                try{startActivityForResult(intent,101);}catch(ActivityNotFoundException ex){exportData=null;toast("No file picker is available.");}
            });
        }
    }
}
