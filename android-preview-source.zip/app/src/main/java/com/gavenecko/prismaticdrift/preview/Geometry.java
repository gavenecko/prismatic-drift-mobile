package com.gavenecko.prismaticdrift.preview;

final class Geometry {
    static double finite(double n,double fallback){return Double.isFinite(n)?n:fallback;}
    static double clamp(double n,double min,double max,double fallback){return Math.max(min,Math.min(max,finite(n,fallback)));}
    static int sides(int sides){return Math.max(1,Math.min(24,sides));}
    static double radius(String family,int point,double theta,double depth){
        if("star".equals(family))return point%2==0?1:clamp(depth,.05,.95,.45);
        if("flower".equals(family))return 1-depth*.5+Math.cos(theta)*depth*.5;
        return 1;
    }
}
