package com.gavenecko.prismaticdrift.preview;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public final class WallpaperSettingsActivity extends Activity {
    private LinearLayout column;
    private SharedPreferences prefs;
    private int pad;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);prefs=getSharedPreferences("wallpaper",MODE_PRIVATE);
        pad=(int)(20*getResources().getDisplayMetrics().density);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(14,20,37));
        column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);column.setPadding(pad,pad,pad,pad);
        scroll.addView(column);setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i.consumeSystemWindowInsets();});
        text("Prismatic Drift",28,true);
        text("Live wallpaper preview",19,true);
        text("A lighter native renderer for your home screen. Main shapes, palettes, speed and trails can be copied from the app. Images, music, extra layers, morphing and feedback are available in the app only in this test.",15,false);
        text("Brightness",17,true);
        TextView brightness=text("",15,false);
        SeekBar slider=new SeekBar(this);slider.setMax(80);slider.setProgress(prefs.getInt("brightness",60)-20);
        brightness.setText((slider.getProgress()+20)+"%");column.addView(slider);
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int value,boolean user){brightness.setText((value+20)+"%");if(user)prefs.edit().putInt("brightness",value+20).apply();}
            public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
        });
        text("Animation rate",17,true);
        Spinner fps=new Spinner(this);
        ArrayAdapter<String> options=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"15 fps · lower power","24 fps · balanced","30 fps · smoother"});
        fps.setAdapter(options);int rate=prefs.getInt("fps",24);fps.setSelection(rate==15?0:rate==30?2:1);column.addView(fps);
        fps.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> p,View v,int at,long id){prefs.edit().putInt("fps",new int[]{15,24,30}[at]).apply();}
            public void onNothingSelected(AdapterView<?> p){}
        });
        Switch touch=new Switch(this);touch.setText("Touch response on home screen");touch.setTextColor(Color.WHITE);touch.setPadding(0,pad,0,pad);touch.setChecked(prefs.getBoolean("touch",true));column.addView(touch);
        touch.setOnCheckedChangeListener((button,enabled)->prefs.edit().putBoolean("touch",enabled).apply());
        text("Stops drawing when hidden. Android battery saver also lowers the frame rate and shape count. Actual touch events and lock-screen availability depend on your launcher and device.",14,false);
        Button set=new Button(this);set.setText("Preview / set live wallpaper");column.addView(set);
        set.setOnClickListener(v->{
            Intent intent=new Intent(android.app.WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(android.app.WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,new ComponentName(this,DriftWallpaperService.class));
            try{startActivity(intent);}catch(ActivityNotFoundException ex){Toast.makeText(this,"This device does not provide a live wallpaper picker.",Toast.LENGTH_LONG).show();}
        });
        Button reset=new Button(this);reset.setText("Reset wallpaper scene");column.addView(reset);
        reset.setOnClickListener(v->{prefs.edit().remove("scene").apply();Toast.makeText(this,"Default polygon scene restored.",Toast.LENGTH_SHORT).show();});
        Button back=new Button(this);back.setText("Back to app");column.addView(back);
        back.setOnClickListener(v->finish());
        text("Prismatic Drift 0.3.0-test1 · Gavenecko\nInspired by John Biddiscombe's Zone Rings from Outer-Space. Independent recreation; no affiliation or endorsement.",13,false);
    }
    private TextView text(String value,int size,boolean heading){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(heading?Color.rgb(217,201,255):Color.rgb(207,218,235));
        if(heading)v.setTypeface(null,android.graphics.Typeface.BOLD);
        v.setPadding(0,pad/2,0,pad/2);column.addView(v);return v;
    }
}
