package com.gavenecko.prismaticdrift.preview;

import android.content.*;
import android.graphics.*;
import android.os.*;
import android.service.wallpaper.WallpaperService;
import android.view.*;
import java.util.ArrayList;
import org.json.*;

public final class DriftWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine(){return new DriftEngine();}
    final class DriftEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        private final Handler handler=new Handler(Looper.getMainLooper());
        private final Runnable frame=this::drawFrame;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fade=new Paint();
        private final Paint bitmapPaint=new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Path path=new Path();
        private final ArrayList<Ring> rings=new ArrayList<>();
        private final SharedPreferences prefs=getSharedPreferences("wallpaper",MODE_PRIVATE);
        private JSONObject controls=new JSONObject();
        private JSONArray weights=new JSONArray(),rgb=new JSONArray();
        private Bitmap buffer;
        private Canvas ink;
        private boolean visible,surfaceReady,dirty=true;
        private int surfaceWidth,surfaceHeight,serial;
        private double t,born,originX,originY,touchX,touchY;
        private long last,touchAt;
        DriftEngine(){setTouchEventsEnabled(true);setOffsetNotificationsEnabled(false);prefs.registerOnSharedPreferenceChangeListener(this);}
        @Override public void onSharedPreferenceChanged(SharedPreferences p,String key){dirty=true;}
        @Override public void onVisibilityChanged(boolean value){visible=value;handler.removeCallbacks(frame);last=0;if(value&&surfaceReady)handler.post(frame);else if(!value)releaseBuffer();}
        @Override public void onSurfaceCreated(SurfaceHolder holder){super.onSurfaceCreated(holder);surfaceReady=true;}
        @Override public void onSurfaceChanged(SurfaceHolder holder,int format,int width,int height){
            super.onSurfaceChanged(holder,format,width,height);surfaceWidth=width;surfaceHeight=height;releaseBuffer();last=0;
            handler.removeCallbacks(frame);if(visible)handler.post(frame);
        }
        @Override public void onSurfaceDestroyed(SurfaceHolder holder){surfaceReady=false;handler.removeCallbacks(frame);releaseBuffer();super.onSurfaceDestroyed(holder);}
        @Override public void onDestroy(){handler.removeCallbacks(frame);prefs.unregisterOnSharedPreferenceChangeListener(this);releaseBuffer();super.onDestroy();}
        @Override public void onTouchEvent(MotionEvent event){
            if(prefs.getBoolean("touch",true)&&buffer!=null){
                touchX=(event.getX()/Math.max(1,surfaceWidth)-.5)*buffer.getWidth();
                touchY=(event.getY()/Math.max(1,surfaceHeight)-.5)*buffer.getHeight();touchAt=SystemClock.uptimeMillis();
            }
            super.onTouchEvent(event);
        }
        private void releaseBuffer(){if(buffer!=null){buffer.recycle();buffer=null;ink=null;}rings.clear();born=0;}
        private double number(String key,double fallback){return Geometry.finite(controls.optDouble(key,fallback),fallback);}
        private boolean flag(String key,boolean fallback){return controls.has(key)?controls.optBoolean(key,fallback):fallback;}
        private void readScene(){
            try{JSONObject scene=new JSONObject(prefs.getString("scene","{}"));controls=scene.optJSONObject("controls");if(controls==null)controls=new JSONObject();weights=scene.optJSONArray("weights");rgb=scene.optJSONArray("rgbPoints");}
            catch(JSONException ex){controls=new JSONObject();weights=null;rgb=null;}
            dirty=false;rings.clear();born=0;if(ink!=null)ink.drawColor(Color.BLACK);
        }
        private int chooseSides(){
            double total=0;for(int i=0;weights!=null&&i<Math.min(24,weights.length());i++)total+=Math.max(0,weights.optDouble(i,0));
            if(total<=0)return 6;
            double n=Math.random()*total;
            for(int i=0;i<Math.min(24,weights.length());i++){n-=Math.max(0,weights.optDouble(i,0));if(n<0)return i+1;}return 6;
        }
        private int colour(int index){
            double u=(index*number("step",22)*.0009+t*number("cycling",15)*.002)%1;if(u<0)u+=1;
            String palette=controls.optString("palette","rainbow");
            double h=u*360,l=.6;
            if("fire".equals(palette)){h=u*65;l=.4+u*.25;}
            else if("ice".equals(palette)){h=175+u*75;l=.45+u*.3;}
            else if("mono".equals(palette)){h=120;l=.25+u*.55;}
            else if("rgb".equals(palette)&&rgb!=null&&rgb.length()>1){
                double pos=u*rgb.length();int at=(int)pos;double f=(1-Math.cos((pos-at)*Math.PI))/2;
                JSONArray a=rgb.optJSONArray(at%rgb.length()),b=rgb.optJSONArray((at+1)%rgb.length());
                if(a!=null&&b!=null){int[] c=new int[3];double gamma=100/Geometry.clamp(number("gamma",100),30,200,100);
                    for(int k=0;k<3;k++)c[k]=(int)(255*Math.pow(Geometry.clamp((a.optDouble(k,0)*(1-f)+b.optDouble(k,0)*f)/255,0,1,0),gamma));
                    return Color.rgb(c[0],c[1],c[2]);}
            }
            double saturation=1;
            double value=l+saturation*Math.min(l,1-l);
            double hsvS=value==0?0:2*(1-l/value);
            return Color.HSVToColor(new float[]{(float)((h%360+360)%360),(float)hsvS,(float)value});
        }
        private void drawFrame(){
            if(!visible||!surfaceReady||surfaceWidth<1||surfaceHeight<1)return;
            PowerManager power=(PowerManager)getSystemService(POWER_SERVICE);
            if(power!=null&&!power.isInteractive()){last=0;handler.postDelayed(frame,1000);return;}
            boolean battery=power!=null&&power.isPowerSaveMode();
            int fps=(battery||prefs.getInt("fps",30)==15)?15:30;
            long now=SystemClock.uptimeMillis();double dt=last==0?1.0/fps:Math.min(.08,(now-last)/1000.0);last=now;t+=dt;
            try{
                if(buffer==null){
                    double scale=Math.min(1,(battery?720.0:960.0)/Math.max(surfaceWidth,surfaceHeight));
                    buffer=Bitmap.createBitmap(Math.max(1,(int)(surfaceWidth*scale)),Math.max(1,(int)(surfaceHeight*scale)),Bitmap.Config.ARGB_8888);
                    ink=new Canvas(buffer);ink.drawColor(Color.BLACK);
                }
                if(dirty)readScene();
                int w=buffer.getWidth(),h=buffer.getHeight();
                if(flag("erase",true)){
                    double duration=Geometry.clamp(number("trail",1.5),0,60,1.5);
                    if(duration<=0)ink.drawColor(Color.BLACK);
                    else{fade.setColor(Color.argb((int)Math.max(1,255*(1-Math.exp(-dt*4/duration))),0,0,0));ink.drawRect(0,0,w,h,fade);}
                }
                double amp=Math.min(w,h)*number("motionAmp",28)*.005;
                double x=Math.sin(t*.25)*amp,y=Math.cos(t*.31)*amp;
                if(prefs.getBoolean("touch",true)&&now-touchAt<1000){x=touchX;y=touchY;}
                if("none".equals(controls.optString("motion")))x=y=0;
                originX+=(x-originX)*(1-Math.exp(-dt*6));originY+=(y-originY)*(1-Math.exp(-dt*6));
                int count=(int)Geometry.clamp(number("count",100),10,battery?60:140,100);
                double life=12/(Geometry.clamp(number("speed",55),10,200,55)/55);
                born+=dt*count/life;
                while(born>=1&&rings.size()<count){born--;rings.add(new Ring(chooseSides(),serial++,originX,originY,t*.13));}
                if(rings.size()>=count)born=0;
                for(int i=rings.size()-1;i>=0;i--){Ring ring=rings.get(i);ring.age+=dt/life;if(ring.age>=1||rings.size()>count){rings.remove(i);continue;}drawRing(ring,w,h);}
                Canvas screen=null;
                try{
                    screen=getSurfaceHolder().lockCanvas();
                    if(screen!=null){screen.drawColor(Color.BLACK);screen.drawBitmap(buffer,null,new Rect(0,0,surfaceWidth,surfaceHeight),bitmapPaint);
                        int brightness=Math.max(20,Math.min(100,prefs.getInt("brightness",60)));screen.drawColor(Color.argb((100-brightness)*255/100,0,0,0));}
                }finally{if(screen!=null)getSurfaceHolder().unlockCanvasAndPost(screen);}
            }catch(IllegalArgumentException|IllegalStateException ex){releaseBuffer();}
            if(visible&&surfaceReady)handler.postDelayed(frame,Math.max(1,1000/fps-(SystemClock.uptimeMillis()-now)));
        }
        private void drawRing(Ring ring,int w,int h){
            double progress=flag("inward",false)?1-ring.age:ring.age;
            double radius=3+Math.pow(progress,1+number("perspective",50)*.018)*Math.hypot(w,h)*.65*Geometry.clamp(number("zoom",100),30,250,100)/100;
            double blend=Math.pow(1-progress,1+number("vanish",30)*.025);
            double cx=w/2.0+ring.x*blend,cy=h/2.0+ring.y*blend;
            String rotation=controls.optString("rotation","sine");
            double angle=ring.angle;
            if("sine".equals(rotation))angle+=Math.sin(t*number("rf",25)*.035+ring.index*.015)*number("ra",45)*.04;
            if("random".equals(rotation))angle+=t*ring.spin*number("ra",45)*.025;
            if(!"none".equals(rotation))angle+=t*number("precession",12)*.008;
            double sx=1+number("ax",18)*.009*Math.sin(t*number("fx",24)*.045+ring.index*.04);
            double sy=1+number("ay",25)*.009*Math.sin(t*number("fy",31)*.045+ring.index*.04+1.4);
            String family=controls.optString("pdFamily","polygon");
            String layerFamily=controls.optString("pdL1Family","inherit");if(!"inherit".equals(layerFamily))family=layerFamily;
            double depth=Geometry.clamp(number("pdDepth",45)/100,.05,.95,.45);
            boolean dots="dots".equals(controls.optString("draw"))||ring.sides==1;
            int vertices="star".equals(family)?ring.sides*2:"flower".equals(family)?ring.sides*8:"spiral".equals(family)?120:ring.sides;
            paint.setColor(colour(ring.index));paint.setStrokeWidth((float)Geometry.clamp(number("lineWidth",1.5),.5,24,1.5));
            paint.setStyle(dots?Paint.Style.FILL:Paint.Style.STROKE);path.reset();
            for(int k=0;k<=vertices;k++){
                double theta=k*Math.PI*2/vertices,r=Geometry.radius(family,k,theta*ring.sides,depth);
                if("spiral".equals(family)){r=k/(double)vertices;theta*=1+depth*4;}
                float px=(float)(cx+Math.cos(theta+angle)*radius*r*sx),py=(float)(cy+Math.sin(theta+angle)*radius*r*sy);
                if(dots){if(k<vertices)ink.drawCircle(px,py,(float)Geometry.clamp(number("dotSize",2),1,30,2)/2,paint);}
                else if(k==0)path.moveTo(px,py);else path.lineTo(px,py);
            }
            if(!dots){if(!"spiral".equals(family))path.close();ink.drawPath(path,paint);}
        }
    }
    private static final class Ring{
        double age,x,y,angle,spin=Math.random()*2-1;int sides,index;
        Ring(int s,int i,double x,double y,double angle){sides=Geometry.sides(s);index=i;this.x=x;this.y=y;this.angle=angle;}
    }
}
