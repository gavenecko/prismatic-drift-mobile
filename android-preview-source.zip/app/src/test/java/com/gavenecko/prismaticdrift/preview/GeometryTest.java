package com.gavenecko.prismaticdrift.preview;
import org.junit.Test;
import static org.junit.Assert.*;
public class GeometryTest {
    @Test public void malformedInputsCannotEscapeRendererBounds(){
        assertEquals(100,Geometry.clamp(Double.NaN,10,140,100),0);
        assertEquals(100,Geometry.clamp(Double.POSITIVE_INFINITY,10,140,100),0);
        assertEquals(140,Geometry.clamp(2000,10,140,100),0);
        assertEquals(1,Geometry.sides(-20));assertEquals(24,Geometry.sides(999));
    }
    @Test public void allShapeFamiliesHaveFinitePositiveRadii(){
        for(String family:new String[]{"polygon","star","flower"})for(int sides=1;sides<=24;sides++)
            for(int k=0;k<=sides*8;k++){
                double radius=Geometry.radius(family,k,k*Math.PI/4,.95);
                assertTrue(family+" radius",Double.isFinite(radius)&&radius>=.049&&radius<=1.001);
            }
    }
    @Test public void starsAlternateOuterAndInnerVertices(){
        assertEquals(1,Geometry.radius("star",0,0,.45),0);
        assertEquals(.45,Geometry.radius("star",1,1,.45),0);
        assertEquals(1,Geometry.radius("star",2,2,.45),0);
    }
}
