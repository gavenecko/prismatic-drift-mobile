# Prismatic Drift Android Preview

Version **0.3.0-test2**. Local Android app + native live wallpaper prototype.

The app bundles the touch/music browser build for offline use. Images and audio
are selected through Android's file picker. Settings exports use the system
Save dialog. Audio and animation pause when the app leaves the foreground.
There is no network permission, account, ad SDK or analytics SDK in this build.

The wallpaper is a separate native renderer, supporting the main shape family,
polygon weights, named/RGB palettes, speed, line/dot size, trail fading and touch
response. Copy a scene using the app's Wallpaper button. Set brightness and
frame rate in Wallpaper settings, then confirm through Android's preview.
Extra layers, morphing, feedback, images and music remain app-only for this test.
The native rendering and trail fading approximate the app, rather than matching
every effect. Lock-screen support and home-screen touch depend on the launcher.

Requires Android 8.0+. First target device: Samsung Galaxy A54.

## Build

JDK 17, Gradle 8.11.1, Android SDK Platform 35 and Build Tools 35.0.0.
Run `gradle testDebugUnitTest lintDebug assembleDebug`.
The GitHub Actions workflow builds a debug-signed test APK. This is not a Play
Store release or production signing setup. Keep signing keys stable for updates;
if Android reports a signature mismatch on a later test build, export settings
and uninstall the previous preview before installing the new one.

## License

Freeware: use and share unchanged. See LICENSE.txt and CREDITS.txt. No original
Zone Rings binary or source is included. Android APIs are provided by the OS;
JUnit 4.13.2 is used only for build-time tests and is not bundled in the app.
